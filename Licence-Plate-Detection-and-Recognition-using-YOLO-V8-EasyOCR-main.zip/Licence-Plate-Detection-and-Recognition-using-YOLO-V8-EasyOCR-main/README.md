# Licence-Plate-Detection-and-Recognition-using-YOLO-V8-EasyOCR
